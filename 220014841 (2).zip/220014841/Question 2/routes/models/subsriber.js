const mongoose = require('mongoose');

const subscriberSchma = new mongoose.Schema({
name:{
    type: String,
    required:ture

},
subsriberToChannel: {
    type: String,
    required:ture
},
subsribeDate:{
    type: date,
    required:ture,
    default: Date.now
}

})
module.exports = mongoose.model('Subscriber', subscriberSchema)