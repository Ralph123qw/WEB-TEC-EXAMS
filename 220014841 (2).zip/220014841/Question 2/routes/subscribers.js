const express = require('express');
const router = express.Router()
const subscriber = require('../models/subscriber')

//Getting all
router.get('/', async(req, req) => {
      try{
           const subscribers = await subscriber.find()
           res.josn(subscribers)
      }catch (err) {
res.status(500).json({message: err.message})
      }
    

})
// Getting One
router.get('/:id',getSubscriber, (req, res) => {
res.send(res.subscriber.name)
})    
//Creating one
router.post('/:id', async(req, req) => {
   constsubscriber = new subscriber({
       name: req.body.name,
       subscribedToChannel: req.body.subscribedToChannel
   })
   try{
const newsubsriber = await subscriber.save()
res.status(201).json(newsubsriber)
   }catch (err) {
       res.status(400)({message: err.messade})

   }
})   
//Updating One
router.patch('/:id', getSubscriber ,(req, req) => {

}) 
//Deleting one
router.delete('/:id',getSubscriber , (req, req) => 
{

}) 
 {
    let subscriber
    try{
subscriber = await subscriber.findById(req.params.id)
if (subscriber == null)
return res.status(404).json({ message: 'Cannot find subscriber'})
    }catch (err){
return res.status(500).json({message: err.message})
    }
    res.subscriber=subscriber
    next()
}

module.exports = router
